import https from 'https';

export const handler = async (event) => {
  const HOST = process.env.APP_URL;
        
  return new Promise((resolve, reject) => {
    const req = https.request(
      HOST + '/api/sync',
      { 
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.SYNC_SECRET}`
        }
      },
      (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve({ statusCode: res.statusCode, body: data }));
      }
    );
          
    req.on('error', (e) => reject(e));
    req.end();
  });
};
